export function Toaster() {
  return <div className="toaster">{/* Toast content */}</div>
}